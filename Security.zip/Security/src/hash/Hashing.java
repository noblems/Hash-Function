/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hash;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Arrays;
import com.google.common.io.BaseEncoding; 
import com.google.common.primitives.Bytes; 
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author NOOBLE
 */
public class Hashing {

    private final int SALT_SIZE=64;
    private final  String passw_ord="this is an uncrackable string";
    int ITERATIONS=10000000;
    private final String ALGORITHM="SHA-512";
    //private final String ALGORITHM="MD5";
    //private final String ALGORITHM="SHA-256";
    public static void main(String[] argv){
        try {
            Hashing h=new Hashing();
            byte[] salt=h.generateSalt();
            byte[] hass =h.calculateHash(h.passw_ord, salt);
            //salt=h.generateSalt();
            if(h.verifyPassword(hass, h.passw_ord, salt)){
                System.out.println("asame");
            }else{
                System.out.println("not same");
            }
            System.out.println(h.toHex(hass));
        } catch (NoSuchAlgorithmException | UnsupportedEncodingException ex) {
            Logger.getLogger(Hashing.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    private String toHex(byte[] hash){
        StringBuilder sb = new StringBuilder();
        for (byte b : hash) 
            sb.append(String.format("%02X ", b));
        return sb.toString();
    }
    private byte[] generateSalt() { 
        SecureRandom random = new SecureRandom(); 
        byte[] salt = new byte[SALT_SIZE]; 
        random.nextBytes(salt); 
 
        return salt; 
    }
    byte[] calculateHash(String message, byte[] salt) throws NoSuchAlgorithmException, 
            UnsupportedEncodingException { 
        MessageDigest md = MessageDigest.getInstance(ALGORITHM); 
        md.reset(); 
        md.update(Bytes.concat(message.getBytes("UTF-8"), salt)); 
        byte[] hash = md.digest(); 
        for (int i = 0; i < ITERATIONS; i++) { 
            md.reset(); 
            hash = md.digest(hash); 
        } 
 
        return hash; 
    } 
    private boolean verifyPassword(byte[] originalHash, String password, byte[] salt) throws 
            NoSuchAlgorithmException, UnsupportedEncodingException { 
        byte[] comparisonHash = calculateHash(password, salt);  
 
        return comparePasswords(originalHash, comparisonHash); 
    } 
 
   
    private boolean comparePasswords(byte[] originalHash, byte[] comparisonHash) { 
        int diff = originalHash.length ^ comparisonHash.length; 
        for (int i = 0; i < originalHash.length && i < comparisonHash.length; i++) { 
            diff |= originalHash[i] ^ comparisonHash[i]; 
        } 
 
        return diff == 0; 
    } 
}
